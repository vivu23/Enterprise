# CS4743Assignment

A three-tier software system built using Java, Maven, and JavaFX