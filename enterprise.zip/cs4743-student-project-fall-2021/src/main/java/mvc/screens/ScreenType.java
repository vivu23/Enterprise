package mvc.screens;

public enum ScreenType {
    LOGIN, PERSONLIST, PERSONDETAIL
}
